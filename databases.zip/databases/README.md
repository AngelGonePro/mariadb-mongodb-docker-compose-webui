# mc-databases

MariaDB and MongoDB for a Minecraft network, with a web panel where one
account is created in **both** databases at once, with the same username and
password, so it works with any plugin, MySQL/MariaDB or MongoDB.

| Service | Image | What it does |
|---|---|---|
| `mariadb` | `mariadb:11.8` | MariaDB server (LTS) |
| `mongo` | `mongo:8.0` | MongoDB server |
| `panel` | built from `./panel` | Accounts, per-database access, managers, databases |
| `phpmyadmin` | `phpmyadmin:5.2.3` | Optional: browse/edit MariaDB data |
| `mongo-express` | `mongo-express:1.0.2` | Optional: browse/edit MongoDB data |

No existing free tool manages users and permissions in both databases from
one place, and the MongoDB web UIs that manage users at all have been
abandoned for years, so the panel is a small purpose-built app. phpMyAdmin and
Mongo Express are kept alongside it for working with the data itself.

Everything is set in `.env`.

## Install / update

One command for both, needing only `curl`, `python3` and Docker:

```bash
curl -fsSL -o /tmp/databases.zip https://github.com/AngelGonePro/mariadb-mongodb-docker-compose-webui/raw/refs/heads/main/databases.zip && python3 -c "import zipfile;open('/tmp/databases-deploy.sh','wb').write(zipfile.ZipFile('/tmp/databases.zip').read('databases/deploy-update.sh'))" && bash /tmp/databases-deploy.sh /tmp/databases.zip ~/databases
```

- **First run:** puts the project in `~/databases`, generates the admin
  password, both database root passwords and the panel's keys in `.env`, and
  stops so you can check `.env` (set `PUBLIC_DB_HOST`, check the ports).
- **Second run:** builds the panel, starts everything, waits until all
  services are healthy and prints where to log in.
- **Later runs:** update in place. Your `.env` and `data/` are kept, new
  settings are added at the bottom, and a pull failure, a failed panel build,
  a bad download or a broken release leaves the install untouched. When the
  MariaDB or MongoDB image changes, both are dumped to `backups/` first.

From inside the install folder, `./deploy-update.sh` does the same using
`DEPLOY_ZIP_URL` from `.env`. Re-run it after any `.env` change.

## The main admin

`ADMIN_USERNAME` / `ADMIN_PASSWORD` in `.env`. It logs in to the panel,
phpMyAdmin and Mongo Express, and is a superuser in both databases. Change
either and re-run the command: both databases are updated, a renamed admin's
old user is removed, and existing admin sessions end.

## Accounts and permissions

**New account** (admin or a manager): username, password (empty = generate),
and an access level per database. The panel creates:

- MariaDB user `name@'%'` with privileges on exactly those databases
  (`my_db` never also matches `myXdb`; `_` is escaped in grants).
- MongoDB users `name` with the same password: one in `admin` holding every
  granted role, and one inside each granted database. So a plugin that only
  asks for host / database / username / password works (it logs in against its
  own database), and so does a URI with `?authSource=admin`.

| Level | MariaDB | MongoDB |
|---|---|---|
| Read only | `SELECT, SHOW VIEW` | `read` |
| Read & write (what plugins need) | data + create/alter/drop/index tables, views, triggers | `readWrite` |
| Full | `ALL PRIVILEGES` on that database (no `GRANT OPTION`) | `readWrite` + `dbAdmin` |

**Managers:** tick *can manage access* on a database for an account. That
account can then log in to the panel and:

- create accounts and give them access to the databases it manages, up to its
  own level there;
- change access on those databases for any non-manager account;
- see / reset the password of, and delete, accounts it created.

Only the admin creates or deletes databases, makes managers, and sees every
account. Any account can log in to see its own access and connection details
and change its own password.

**Passwords** are stored encrypted with `CREDENTIAL_KEY` (MongoDB needs an
account's password each time it gets a new database). Keep `.env` with your
backups: without that key the stored passwords can't be read and every account
needs a new one set in the panel.

**Re-apply all accounts** (admin page) rebuilds every account's users,
password and access in both databases, e.g. after restoring a backup or
editing users by hand in phpMyAdmin / Mongo Express.

## Plugin settings

The panel shows these per account. With `PUBLIC_DB_HOST=10.0.0.152`:

- MariaDB / MySQL: host `10.0.0.152`, port `3316`, database, username, password
  (`jdbc:mariadb://10.0.0.152:3316/luckperms`)
- MongoDB: `mongodb://luckperms:<password>@10.0.0.152:27027/luckperms`

The database ports are 3316 and 27027 so they can't collide with another
MariaDB/MySQL or MongoDB already on the host. Set `DB_BIND` to a LAN IP to
keep them off other interfaces; only your Minecraft servers need them.

## Web access

`PANEL_PORT` (8750), `PHPMYADMIN_PORT` (8751) and `MONGO_EXPRESS_PORT` (8752)
only need to reach your reverse proxy. Site configs for local access through
the home proxy are supplied separately
(`proxy-nginx-db/pma/mongo.cosmoscraft.net.conf`): HTTPS on 443 with the
wildcard cert, port 80 redirecting to it, private address ranges only. Point
each name at the proxy's LAN IP with a DNS-only (not proxied) record, and put
the proxy's IP in `TRUSTED_PROXIES` so login throttling sees the real client.

Turn the optional tools off with `COMPOSE_PROFILES=` (empty) or keep one,
e.g. `COMPOSE_PROFILES=phpmyadmin`.

## Security notes

- MariaDB `root` has no network login at all; the panel reaches it over the
  MariaDB socket shared between the two containers.
- MongoDB `root` and the panel keys are random 32-48 character values.
  `MARIADB_ROOT_PASSWORD`, `MONGO_ROOT_*` and `CREDENTIAL_KEY` only take
  effect when the data is first created; the update command refuses to run if
  they've been edited since, rather than locking the panel out.
- Failed logins are throttled per IP (`LOGIN_MAX_FAILURES`,
  `LOGIN_BLOCK_MINUTES`); every action is logged (`docker compose logs panel`).

## Backups

Automatic dumps happen only before a database image change. For a manual
one:

```bash
cd ~/databases
docker compose exec -T mariadb sh -c 'exec mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" --all-databases --single-transaction' | gzip > backups/mariadb-manual.sql.gz
docker compose exec -T mongo sh -c 'exec mongodump --quiet --archive --gzip -u "$MONGO_INITDB_ROOT_USERNAME" -p "$MONGO_INITDB_ROOT_PASSWORD" --authenticationDatabase admin' > backups/mongo-manual.archive.gz
```
