'use strict';
const crypto = require('crypto');
const cfg = require('./config');

// --- Stored account passwords ------------------------------------------------
// MongoDB needs an account's password every time it gets access to another
// database (a separate user is created inside each database so plugins that
// log in against their own database work). So the panel keeps each password
// encrypted with CREDENTIAL_KEY from .env (AES-256-GCM). The database alone
// is not enough to read them.
const credKey = crypto.createHash('sha256').update('cred:' + cfg.credentialKey).digest();

function encrypt(plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', credKey, iv);
  const ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64');
}

function decrypt(blob) {
  const b = Buffer.from(blob, 'base64');
  const d = crypto.createDecipheriv('aes-256-gcm', credKey, b.subarray(0, 12));
  d.setAuthTag(b.subarray(12, 28));
  return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8');
}

function safeEqual(a, b) {
  const x = crypto.createHash('sha256').update(String(a)).digest();
  const y = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(x, y) && String(a) === String(b);
}

// No characters that break shell, URI or YAML quoting in plugin configs.
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
function generatePassword(len = cfg.generatedPasswordLength) {
  let out = '';
  while (out.length < len) {
    const byte = crypto.randomBytes(1)[0];
    if (byte < 256 - (256 % ALPHABET.length)) out += ALPHABET[byte % ALPHABET.length];
  }
  return out;
}

// --- Sessions ----------------------------------------------------------------
const sessKey = crypto.createHash('sha256').update('sess:' + cfg.sessionSecret).digest();
const mac = (s) => crypto.createHmac('sha256', sessKey).update(s).digest('base64url');

function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  return body + '.' + mac(body);
}

function unsign(token) {
  if (typeof token !== 'string' || !token.includes('.')) return null;
  const [body, sig] = token.split('.', 2);
  const expect = mac(body);
  if (sig.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expect))) return null;
  try {
    const p = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!p.exp || p.exp < Date.now()) return null;
    return p;
  } catch {
    return null;
  }
}

const csrfFor = (sid) => mac('csrf:' + sid);

// Ties an admin session to the current .env password: changing ADMIN_PASSWORD
// (or ADMIN_USERNAME) logs every admin session out.
const adminStamp = () => mac('admin:' + cfg.adminUser + ':' + cfg.adminPassword).slice(0, 16);

// --- Login throttling (per client IP, in memory) -----------------------------
const failures = new Map();
function loginBlocked(ip) {
  const f = failures.get(ip);
  if (!f) return false;
  if (Date.now() - f.first > cfg.loginBlockMinutes * 60000) {
    failures.delete(ip);
    return false;
  }
  return f.count >= cfg.loginMaxFailures;
}
function loginFailed(ip) {
  const f = failures.get(ip);
  if (!f || Date.now() - f.first > cfg.loginBlockMinutes * 60000) failures.set(ip, { count: 1, first: Date.now() });
  else f.count++;
  if (failures.size > 10000) failures.delete(failures.keys().next().value);
}
const loginSucceeded = (ip) => failures.delete(ip);

module.exports = {
  encrypt, decrypt, safeEqual, generatePassword,
  sign, unsign, csrfFor, adminStamp,
  loginBlocked, loginFailed, loginSucceeded,
};
