'use strict';
const crypto = require('crypto');
const express = require('express');
const cfg = require('./config');
const db = require('./db');
const sec = require('./security');
const views = require('./views');

const { PanelError, levelRank } = db;
const SESSION_COOKIE = 'dbpanel_session';
const FLASH_COOKIE = 'dbpanel_flash';

const app = express();
app.disable('x-powered-by');
if (cfg.trustedProxies) app.set('trust proxy', cfg.trustedProxies.split(',').map((s) => s.trim()).filter(Boolean));
app.use(express.urlencoded({ extended: false, limit: '64kb', parameterLimit: 2000 }));
app.use((req, res, next) => {
  res.set({
    'X-Frame-Options': 'DENY',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'same-origin',
    'Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",
  });
  next();
});

// ------------------------------------------------------------- cookies ---
function cookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function setCookie(req, res, name, value, maxAgeSec) {
  const secure = cfg.cookieSecure === 'true' || (cfg.cookieSecure === 'auto' && req.secure);
  res.append('Set-Cookie', `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSec}${secure ? '; Secure' : ''}`);
}
function flash(req, res, msg, err = false) {
  setCookie(req, res, FLASH_COOKIE, sec.sign({ msg: String(msg).slice(0, 500), err, exp: Date.now() + 60000 }), 60);
}
function takeFlash(req, res) {
  const f = sec.unsign(cookies(req)[FLASH_COOKIE]);
  if (cookies(req)[FLASH_COOKIE]) setCookie(req, res, FLASH_COOKIE, '', 0);
  return f;
}

// ------------------------------------------------------------- session ---
async function loadMe(req) {
  const s = sec.unsign(cookies(req)[SESSION_COOKIE]);
  if (!s) return null;
  if (s.a) {
    if (s.u !== cfg.adminUser || s.v !== sec.adminStamp()) return null;
    return { name: s.u, isAdmin: true, managed: new Set(), grants: new Map(), sid: s.sid, csrf: sec.csrfFor(s.sid) };
  }
  const a = await db.accountRow(s.u);
  if (!a || a.pw_version !== s.v) return null;
  const grants = await db.grantsOf(a.name);
  const managed = new Set([...grants].filter(([, g]) => g.manage).map(([d]) => d));
  return { name: a.name, isAdmin: false, managed, grants, sid: s.sid, csrf: sec.csrfFor(s.sid) };
}

function startSession(req, res, payload) {
  const sid = crypto.randomBytes(16).toString('base64url');
  setCookie(req, res, SESSION_COOKIE, sec.sign({ ...payload, sid, exp: Date.now() + cfg.sessionHours * 3600000 }), cfg.sessionHours * 3600);
}

const requireLogin = async (req, res, next) => {
  req.me = await loadMe(req);
  if (!req.me) return res.redirect(303, '/login');
  if (req.method === 'POST') {
    const t = String(req.body?._csrf || '');
    if (t.length !== req.me.csrf.length || !crypto.timingSafeEqual(Buffer.from(t), Buffer.from(req.me.csrf)))
      return res.status(403).send(views.message(req.me, 'Expired form', 'That form was stale. Go back, reload the page and try again.'));
  }
  next();
};

// --------------------------------------------------------- permissions ---
// Databases `me` may hand out on `target`'s account (or on a new account).
async function editableFor(me, targetGrants) {
  if (me.isAdmin) return (await db.listDatabases()).map((d) => ({ name: d.name, maxLevel: 'admin', canManageFlag: true }));
  return [...me.managed].sort()
    .filter((d) => !targetGrants?.get(d)?.manage) // a fellow manager's access is the admin's call
    .map((d) => ({ name: d, maxLevel: me.grants.get(d).level, canManageFlag: false }));
}

// Reads the access table of a submitted form into changes for the editable rows.
function readGrantForm(body, editable, current) {
  const changes = new Map();
  for (const d of editable) {
    const level = String(body['level:' + d.name] || '');
    if (level && (!db.LEVELS.includes(level) || levelRank(level) > levelRank(d.maxLevel)))
      throw new PanelError(`You can't give ${level} access to ${d.name}.`);
    const manage = d.canManageFlag ? body['manage:' + d.name] === '1' : !!current?.get(d.name)?.manage;
    const before = current?.get(d.name);
    if (!level) {
      if (before) changes.set(d.name, null);
    } else if (!before || before.level !== level || before.manage !== manage) {
      changes.set(d.name, { level, manage });
    }
  }
  return changes;
}

function visibleTo(me, acct) {
  if (me.isAdmin) return true;
  if (acct.name === me.name || me.managed.size === 0) return false;
  return acct.created_by === me.name || [...acct.grants.keys()].some((d) => me.managed.has(d));
}
const canPassword = (me, a) => me.isAdmin || (me.managed.size > 0 && a.created_by === me.name && a.name !== me.name);
const canDelete = (me, a, grants) => canPassword(me, a) && (me.isAdmin || ![...grants.values()].some((g) => g.manage));

async function loadTarget(req, res) {
  const a = await db.accountRow(req.params.name);
  const grants = a ? await db.grantsOf(a.name) : null;
  if (!a || !visibleTo(req.me, { ...a, grants })) {
    res.status(404).send(views.message(req.me, 'Not found', 'No such account, or it is not one you manage.'));
    return null;
  }
  return { a, grants };
}

// -------------------------------------------------------------- routes ---
app.use((req, res, next) => {
  if (req.method === 'GET' && req.path !== '/healthz') res.locals.flash = takeFlash(req, res);
  next();
});

app.get('/healthz', async (req, res) => {
  try {
    await db.ping();
    res.type('text').send('ok');
  } catch (e) {
    res.status(503).type('text').send('database unreachable: ' + e.message);
  }
});

app.get('/login', async (req, res) => {
  if (await loadMe(req)) return res.redirect(303, '/');
  res.send(views.login());
});

app.post('/login', async (req, res) => {
  const ip = req.ip;
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  if (sec.loginBlocked(ip)) return res.status(429).send(views.login(`Too many failed logins. Try again in ${cfg.loginBlockMinutes} minutes.`, username));
  if (username === cfg.adminUser && sec.safeEqual(password, cfg.adminPassword)) {
    sec.loginSucceeded(ip);
    startSession(req, res, { u: username, a: 1, v: sec.adminStamp() });
    return res.redirect(303, '/');
  }
  const a = db.NAME_RE.test(username) ? await db.accountRow(username) : null;
  if (a && sec.safeEqual(password, sec.decrypt(a.secret))) {
    sec.loginSucceeded(ip);
    startSession(req, res, { u: a.name, a: 0, v: a.pw_version });
    return res.redirect(303, '/');
  }
  sec.loginFailed(ip);
  console.log(`failed login for "${username.slice(0, 40)}" from ${ip}`);
  res.status(401).send(views.login('Wrong username or password.', username));
});

app.post('/logout', requireLogin, (req, res) => {
  setCookie(req, res, SESSION_COOKIE, '', 0);
  res.redirect(303, '/login');
});

app.get('/', requireLogin, async (req, res) => {
  const me = req.me;
  const isMgr = me.isAdmin || me.managed.size > 0;
  const accounts = isMgr ? (await db.listAccounts()).filter((a) => visibleTo(me, a)) : [];
  let dbs = [];
  if (me.isAdmin) {
    const all = await db.listAccounts();
    dbs = (await db.listDatabases()).map((d) => ({ ...d, users: all.filter((a) => a.grants.has(d.name)).length }));
  }
  const editable = isMgr ? await editableFor(me, null) : [];
  res.send(views.home(me, { accounts, dbs, editable, myGrants: me.grants }, res.locals.flash));
});

app.post('/accounts', requireLogin, async (req, res) => {
  const me = req.me;
  if (!me.isAdmin && me.managed.size === 0) return res.status(403).send(views.message(me, 'Not allowed', 'Only managers can create accounts.'));
  const name = String(req.body.name || '').trim();
  let password = String(req.body.password || '');
  if (!password) password = sec.generatePassword();
  try {
    const editable = await editableFor(me, null);
    const grants = readGrantForm(req.body, editable, null);
    await db.createAccount({ name, password, note: String(req.body.note || '').trim(), grants, createdBy: me.name });
  } catch (e) {
    if (!(e instanceof PanelError)) console.error(e);
    flash(req, res, 'Account not created: ' + e.message, true);
    return res.redirect(303, '/');
  }
  console.log(`${me.name} created account ${name}`);
  const a = await db.accountRow(name);
  const grants = await db.grantsOf(name);
  res.send(views.account(me, a, {
    grants, editable: await editableFor(me, grants), canPassword: canPassword(me, a),
    canDelete: canDelete(me, a, grants), created: password,
  }));
});

async function accountPage(req, res, extra = {}) {
  const t = await loadTarget(req, res);
  if (!t) return;
  res.send(views.account(req.me, t.a, {
    grants: t.grants, editable: await editableFor(req.me, t.grants),
    canPassword: canPassword(req.me, t.a), canDelete: canDelete(req.me, t.a, t.grants),
    flash: res.locals.flash, ...extra,
  }));
}

app.get('/accounts/:name', requireLogin, (req, res) => accountPage(req, res));

app.post('/accounts/:name/grants', requireLogin, async (req, res) => {
  const t = await loadTarget(req, res);
  if (!t) return;
  try {
    if (t.a.name === req.me.name) throw new PanelError("You can't change your own access.");
    const changes = readGrantForm(req.body, await editableFor(req.me, t.grants), t.grants);
    if (changes.size) await db.updateGrants(t.a.name, changes);
    if (changes.size) console.log(`${req.me.name} changed access of ${t.a.name}: ${[...changes].map(([d, g]) => d + '=' + (g ? g.level + (g.manage ? '+manage' : '') : 'none')).join(' ')}`);
    flash(req, res, changes.size ? 'Access saved in MariaDB and MongoDB.' : 'Nothing changed.');
  } catch (e) {
    if (!(e instanceof PanelError)) console.error(e);
    flash(req, res, 'Access not changed: ' + e.message, true);
  }
  res.redirect(303, '/accounts/' + t.a.name);
});

app.post('/accounts/:name/reveal', requireLogin, async (req, res) => {
  const t = await loadTarget(req, res);
  if (!t) return;
  if (!canPassword(req.me, t.a)) return res.status(403).send(views.message(req.me, 'Not allowed', 'Only the admin or the manager who created this account can see its password.'));
  await accountPage(req, res, { revealed: await db.passwordOf(t.a.name) });
});

app.post('/accounts/:name/password', requireLogin, async (req, res) => {
  const t = await loadTarget(req, res);
  if (!t) return;
  if (!canPassword(req.me, t.a)) return res.status(403).send(views.message(req.me, 'Not allowed', 'Only the admin or the manager who created this account can change its password.'));
  let password = String(req.body.password || '');
  if (!password) password = sec.generatePassword();
  try {
    await db.setPassword(t.a.name, password);
  } catch (e) {
    if (!(e instanceof PanelError)) console.error(e);
    flash(req, res, 'Password not changed: ' + e.message, true);
    return res.redirect(303, '/accounts/' + t.a.name);
  }
  console.log(`${req.me.name} set a new password for ${t.a.name}`);
  res.locals.flash = { msg: 'New password set in MariaDB and MongoDB.' };
  await accountPage(req, res, { revealed: password });
});

app.post('/accounts/:name/delete', requireLogin, async (req, res) => {
  const t = await loadTarget(req, res);
  if (!t) return;
  if (!canDelete(req.me, t.a, t.grants)) return res.status(403).send(views.message(req.me, 'Not allowed', 'You can only delete accounts you created that are not managers.'));
  await db.deleteAccount(t.a.name);
  console.log(`${req.me.name} deleted account ${t.a.name}`);
  flash(req, res, `Deleted ${t.a.name} from MariaDB and MongoDB.`);
  res.redirect(303, '/');
});

app.post('/me/password', requireLogin, async (req, res) => {
  const me = req.me;
  if (me.isAdmin) return res.status(400).send(views.message(me, 'Admin password', 'The admin password is set in .env (ADMIN_PASSWORD).'));
  try {
    if (!sec.safeEqual(String(req.body.current || ''), await db.passwordOf(me.name))) throw new PanelError('Current password is wrong.');
    await db.setPassword(me.name, String(req.body.password || ''));
  } catch (e) {
    if (!(e instanceof PanelError)) console.error(e);
    flash(req, res, 'Password not changed: ' + e.message, true);
    return res.redirect(303, '/');
  }
  const a = await db.accountRow(me.name);
  startSession(req, res, { u: a.name, a: 0, v: a.pw_version });
  flash(req, res, 'Password changed in MariaDB and MongoDB.');
  res.redirect(303, '/');
});

const adminOnly = (req, res, next) => (req.me.isAdmin ? next()
  : res.status(403).send(views.message(req.me, 'Not allowed', 'Only the admin can do that.')));

app.post('/databases', requireLogin, adminOnly, async (req, res) => {
  const name = String(req.body.name || '').trim();
  try {
    await db.createDatabase(name, req.me.name);
    console.log(`${req.me.name} created database ${name}`);
    flash(req, res, `Database ${name} created.`);
  } catch (e) {
    if (!(e instanceof PanelError)) console.error(e);
    flash(req, res, 'Database not created: ' + e.message, true);
  }
  res.redirect(303, '/');
});

app.post('/databases/:name/delete', requireLogin, adminOnly, async (req, res) => {
  const name = req.params.name;
  try {
    if (String(req.body.confirm || '') !== name) throw new PanelError(`Type the name "${name}" to confirm.`);
    await db.dropDatabase(name);
    console.log(`${req.me.name} deleted database ${name}`);
    flash(req, res, `Database ${name} deleted from MariaDB and MongoDB.`);
  } catch (e) {
    if (!(e instanceof PanelError)) console.error(e);
    flash(req, res, 'Database not deleted: ' + e.message, true);
  }
  res.redirect(303, '/');
});

app.post('/sync', requireLogin, adminOnly, async (req, res) => {
  const problems = await db.syncAll();
  flash(req, res, problems.length ? 'Some accounts failed: ' + problems.join(' | ') : 'Every account re-applied to MariaDB and MongoDB.', problems.length > 0);
  res.redirect(303, '/');
});

app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(err);
  res.status(500).send(views.message(req.me || null, 'Error', err.message));
});

(async () => {
  await db.connect();
  await db.ensureAdmin();
  app.listen(cfg.listenPort, '0.0.0.0', () => console.log(`panel listening on :${cfg.listenPort} (admin user: ${cfg.adminUser})`));
})().catch((e) => {
  console.error('startup failed: ' + e.message);
  process.exit(1);
});
