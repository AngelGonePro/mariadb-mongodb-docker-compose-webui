'use strict';
const cfg = require('./config');
const { LEVELS, LEVEL_LABEL } = require('./db');

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// Tagged template: interpolations are escaped unless wrapped in raw().
class Raw { constructor(s) { this.s = s; } }
const raw = (s) => new Raw(s);
function html(strings, ...vals) {
  let out = strings[0];
  vals.forEach((v, i) => {
    if (Array.isArray(v)) out += v.map((x) => (x instanceof Raw ? x.s : esc(x))).join('');
    else out += v instanceof Raw ? v.s : v === false || v == null ? '' : esc(v);
    out += strings[i + 1];
  });
  return raw(out);
}

const CSS = `
:root{--bg:#f4f5f7;--card:#fff;--ink:#1c1f24;--mute:#626b78;--line:#dfe2e7;--acc:#2f6f4f;--acc-ink:#fff;
--soft:#eaf3ee;--bad:#b3261e;--bad-soft:#fbeaea;--warn-soft:#fff6e0;--code:#f1f3f5;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--bg:#121417;--card:#1b1e23;--ink:#e6e8eb;--mute:#9aa3ae;--line:#2c3138;
--acc:#5fbf8b;--acc-ink:#0d1a12;--soft:#1d2b23;--bad:#f08a84;--bad-soft:#341d1c;--warn-soft:#322a16;--code:#23272d;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
a{color:var(--acc)}header{background:var(--card);border-bottom:1px solid var(--line)}
.bar{max-width:1100px;margin:0 auto;padding:12px 16px;display:flex;gap:16px;align-items:center;flex-wrap:wrap}
.brand{font-weight:700;font-size:17px;margin-right:auto;text-decoration:none;color:var(--ink)}
.who{color:var(--mute);font-size:14px}main{max-width:1100px;margin:0 auto;padding:20px 16px 60px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:18px 20px;margin-bottom:18px}
h1{font-size:22px;margin:0 0 14px}h2{font-size:17px;margin:0 0 12px}h3{font-size:15px;margin:16px 0 8px}
.mute{color:var(--mute)}.small{font-size:13px}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:8px 6px;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--mute);font-weight:600}
.wrap{overflow-x:auto}.chip{display:inline-block;padding:1px 8px;margin:2px 4px 2px 0;border-radius:999px;background:var(--soft);font-size:13px;white-space:nowrap}
.chip b{font-weight:600}.badge{font-size:12px;padding:1px 7px;border-radius:5px;border:1px solid var(--line);color:var(--mute)}
input[type=text],input[type=password],select{font:inherit;color:inherit;background:var(--bg);border:1px solid var(--line);border-radius:7px;padding:7px 9px;width:100%}
label{display:block;font-size:13px;color:var(--mute);margin-bottom:4px}.row{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));margin-bottom:12px}
button,.btn{font:inherit;font-weight:600;border:0;border-radius:7px;padding:8px 14px;background:var(--acc);color:var(--acc-ink);cursor:pointer;text-decoration:none;display:inline-block}
button.ghost{background:transparent;color:var(--ink);border:1px solid var(--line)}button.danger{background:var(--bad);color:#fff}
.inline{display:inline}.flash{padding:10px 14px;border-radius:8px;margin-bottom:16px;background:var(--soft)}
.flash.err{background:var(--bad-soft);color:var(--bad)}code,.code{font-family:ui-monospace,Consolas,monospace;font-size:13px;background:var(--code);padding:2px 6px;border-radius:5px;word-break:break-all}
.secret{font-family:ui-monospace,Consolas,monospace;font-size:16px;background:var(--warn-soft);padding:8px 12px;border-radius:7px;display:inline-block;word-break:break-all}
.grid2{display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(320px,1fr))}
.login{max-width:380px;margin:9vh auto}.ok{color:var(--acc);font-weight:600}.no{color:var(--mute)}
.actions{display:flex;gap:8px;flex-wrap:wrap;align-items:end}
`;

function layout(me, title, body, flash) {
  return html`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} · ${cfg.title}</title>
<style>${raw(CSS)}</style></head><body>
${me ? html`<header><div class="bar"><a class="brand" href="/">${cfg.title}</a>
${me.isAdmin && cfg.phpMyAdminUrl ? html`<a href="${cfg.phpMyAdminUrl}" target="_blank" rel="noopener">phpMyAdmin</a>` : ''}
${me.isAdmin && cfg.mongoExpressUrl ? html`<a href="${cfg.mongoExpressUrl}" target="_blank" rel="noopener">Mongo Express</a>` : ''}
<span class="who">${me.name} <span class="badge">${me.isAdmin ? 'admin' : me.managed.size ? 'manager' : 'user'}</span></span>
<form class="inline" method="post" action="/logout">${csrf(me)}<button class="ghost">Log out</button></form></div></header>` : ''}
<main>${flash ? html`<div class="flash ${flash.err ? 'err' : ''}">${flash.msg}</div>` : ''}${body}</main>
<script>
document.addEventListener('click',e=>{const b=e.target.closest('[data-copy]');if(!b)return;
navigator.clipboard?.writeText(b.dataset.copy).then(()=>{const t=b.textContent;b.textContent='Copied';setTimeout(()=>b.textContent=t,1200)})});
document.addEventListener('submit',e=>{const m=e.target.dataset.confirm;if(m&&!confirm(m))e.preventDefault()});
</script></body></html>`.s;
}

const csrf = (me) => html`<input type="hidden" name="_csrf" value="${me.csrf}">`;

function login(error, username) {
  return layout(null, 'Log in', html`<div class="login card"><h1>${cfg.title}</h1>
${error ? html`<div class="flash err">${error}</div>` : ''}
<form method="post" action="/login"><div style="margin-bottom:12px"><label for="u">Username</label>
<input type="text" id="u" name="username" value="${username || ''}" autocomplete="username" required autofocus></div>
<div style="margin-bottom:16px"><label for="p">Password</label>
<input type="password" id="p" name="password" autocomplete="current-password" required></div>
<button>Log in</button></form></div>`);
}

const chips = (grants) => grants.size
  ? [...grants].map(([db, g]) => html`<span class="chip"><b>${db}</b> · ${LEVEL_LABEL[g.level]}${g.manage ? ' · manages' : ''}</span>`)
  : html`<span class="mute small">no databases</span>`;

function connectInfo(user, dbs) {
  const db = dbs[0] || '<database>';
  const mh = `${cfg.publicMariaHost}:${cfg.publicMariaPort}`;
  const gh = `${cfg.publicMongoHost}:${cfg.publicMongoPort}`;
  const u = user || '<username>';
  return html`<table><tbody>
<tr><th style="width:150px">MariaDB / MySQL</th><td>host <code>${cfg.publicMariaHost}</code> port <code>${cfg.publicMariaPort}</code><br>
<span class="small mute">JDBC:</span> <code>jdbc:mariadb://${mh}/${db}</code> <span class="small mute">(MySQL plugins: <code>jdbc:mysql://${mh}/${db}</code>)</span></td></tr>
<tr><th>MongoDB</th><td>host <code>${cfg.publicMongoHost}</code> port <code>${cfg.publicMongoPort}</code>, database <code>${db}</code>, same username and password<br>
<span class="small mute">URI:</span> <code>mongodb://${u}:&lt;password&gt;@${gh}/${db}</code>
<div class="small mute" style="margin-top:4px">The account exists inside each database it can use, so plugins that only ask for host / database /
username / password work as-is. A URI with <code>?authSource=admin</code> also works.</div></td></tr>
</tbody></table>`;
}

// Database rows of the access editor. editable: [{name, maxLevel, canManageFlag}]
function grantEditor(editable, current, prefix = '') {
  if (!editable.length) return html`<p class="mute">No databases you can give access to yet.</p>`;
  return html`<div class="wrap"><table><thead><tr><th>Database</th><th>Access (MariaDB + MongoDB)</th><th>Manager</th></tr></thead><tbody>
${editable.map((d) => {
    const g = current?.get(d.name);
    const opts = LEVELS.filter((l) => LEVELS.indexOf(l) <= LEVELS.indexOf(d.maxLevel));
    return html`<tr><td><b>${d.name}</b></td><td><select name="${prefix}level:${d.name}">
<option value="">No access</option>${opts.map((l) => html`<option value="${l}" ${raw(g?.level === l ? 'selected' : '')}>${LEVEL_LABEL[l]}</option>`)}
</select></td><td>${d.canManageFlag
      ? html`<label class="inline"><input type="checkbox" name="${prefix}manage:${d.name}" value="1" ${raw(g?.manage ? 'checked' : '')}> can manage access</label>`
      : html`<span class="mute small">${g?.manage ? 'yes' : '—'}</span>`}</td></tr>`;
  })}</tbody></table></div>
<p class="small mute">Read only: SELECT · Read &amp; write: data and tables (what most plugins need) · Full: everything in that database.
A manager can create accounts and give access to the databases they manage, up to their own level.</p>`;
}

function home(me, { accounts, dbs, editable, myGrants }, flash) {
  const isMgr = me.isAdmin || me.managed.size > 0;
  const body = [];
  if (!me.isAdmin) {
    body.push(html`<div class="grid2"><div class="card"><h2>My access</h2>${chips(myGrants)}
<h3>Connect a plugin</h3>${connectInfo(me.name, [...myGrants.keys()])}</div>
<div class="card"><h2>Change my password</h2><form method="post" action="/me/password">${csrf(me)}
<div class="row"><div><label>Current password</label><input type="password" name="current" autocomplete="current-password" required></div></div>
<div class="row"><div><label>New password (${cfg.minPasswordLength}+ characters)</label><input type="password" name="password" autocomplete="new-password" required></div></div>
<button>Change password</button><p class="small mute">Changes it in MariaDB and MongoDB. Update any plugin configs that use this account.</p></form></div></div>`);
  }
  if (isMgr) {
    body.push(html`<div class="card"><h2>Accounts</h2>${accounts.length ? html`<div class="wrap"><table><thead><tr><th>Name</th><th>Access</th><th>Created by</th><th></th></tr></thead><tbody>
${accounts.map((a) => html`<tr><td><a href="/accounts/${a.name}"><b>${a.name}</b></a>${a.note ? html`<div class="small mute">${a.note}</div>` : ''}</td><td>${chips(a.grants)}</td>
<td class="small mute">${a.created_by}</td><td><a class="btn" href="/accounts/${a.name}">Open</a></td></tr>`)}
</tbody></table></div>` : html`<p class="mute">No accounts yet.</p>`}</div>
<div class="card"><h2>New account</h2><p class="small mute" style="margin-top:-6px">Creates the same username and password in MariaDB and MongoDB.</p>
<form method="post" action="/accounts">${csrf(me)}<div class="row">
<div><label>Username</label><input type="text" name="name" pattern="[A-Za-z][A-Za-z0-9_]{1,31}" required placeholder="luckperms"></div>
<div><label>Password (leave empty to generate one)</label><input type="password" name="password" autocomplete="new-password"></div>
<div><label>Note (optional)</label><input type="text" name="note" maxlength="200" placeholder="Survival server LuckPerms"></div></div>
${grantEditor(editable, null)}<button>Create account</button></form></div>`);
  }
  if (me.isAdmin) {
    body.push(html`<div class="card"><h2>Databases</h2>${dbs.length ? html`<div class="wrap"><table><thead><tr><th>Name</th><th>MariaDB</th><th>MongoDB</th><th>Accounts</th><th></th></tr></thead><tbody>
${dbs.map((d) => html`<tr><td><b>${d.name}</b></td><td>${d.inMaria ? html`<span class="ok">yes</span>` : html`<span class="no">not created</span>`}</td>
<td>${d.inMongo ? html`<span class="ok">has data</span>` : html`<span class="no">empty until first write</span>`}</td><td>${d.users}</td>
<td><form method="post" action="/databases/${d.name}/delete" class="actions" data-confirm="Delete ${d.name} and ALL its data in MariaDB and MongoDB?">${csrf(me)}
<input type="text" name="confirm" placeholder="type ${d.name}" style="width:150px" required><button class="danger">Delete</button></form></td></tr>`)}
</tbody></table></div>` : html`<p class="mute">No databases yet.</p>`}
<h3>New database</h3><form method="post" action="/databases" class="actions">${csrf(me)}
<div><label>Name (letters, digits, _)</label><input type="text" name="name" pattern="[A-Za-z0-9_]{1,63}" required placeholder="luckperms"></div>
<button>Create in both</button></form>
<p class="small mute">Databases a plugin creates on its own also show up here. MongoDB only lists a database once something is written to it; access works before that.</p></div>
<div class="grid2"><div class="card"><h2>Connect a plugin</h2>${connectInfo(null, [])}</div>
<div class="card"><h2>Repair</h2><p class="small">Re-applies every account's password and access to both databases, e.g. after restoring a backup
or editing users in phpMyAdmin / Mongo Express.</p><form method="post" action="/sync">${csrf(me)}<button class="ghost">Re-apply all accounts</button></form></div></div>`);
  }
  return layout(me, 'Home', body, flash);
}

function account(me, a, { grants, editable, canPassword, canDelete, revealed, created, flash }) {
  const dbs = [...grants.keys()];
  return layout(me, a.name, html`<p><a href="/">← All accounts</a></p>
${created ? html`<div class="card"><h2>Account created</h2><p>Save this password now${canPassword ? ' (you can show it again here later)' : ''}:</p>
<span class="secret">${created}</span> <button class="ghost" type="button" data-copy="${created}">Copy</button></div>` : ''}
<div class="card"><h1>${a.name}</h1>${a.note ? html`<p>${a.note}</p>` : ''}<p class="small mute">Created by ${a.created_by} · ${new Date(a.created_at).toISOString().slice(0, 16).replace('T', ' ')} UTC</p>
${chips(grants)}<h3>Connect a plugin</h3>${connectInfo(a.name, dbs)}</div>
<div class="card"><h2>Access</h2><form method="post" action="/accounts/${a.name}/grants">${csrf(me)}${grantEditor(editable, grants)}
${editable.length ? html`<button>Save access</button>` : ''}</form></div>
${canPassword ? html`<div class="grid2"><div class="card"><h2>Password</h2>
${revealed ? html`<p><span class="secret">${revealed}</span> <button class="ghost" type="button" data-copy="${revealed}">Copy</button></p>`
    : html`<form method="post" action="/accounts/${a.name}/reveal" style="margin-bottom:14px">${csrf(me)}<button class="ghost">Show password</button></form>`}
<form method="post" action="/accounts/${a.name}/password">${csrf(me)}<div class="row"><div><label>New password (empty = generate)</label>
<input type="password" name="password" autocomplete="new-password"></div></div><button>Set new password</button>
<p class="small mute">Changes it in MariaDB and MongoDB. Plugins using the old one stop connecting until their config is updated.</p></form></div>
${canDelete ? html`<div class="card"><h2>Delete account</h2><p class="small">Removes the user from MariaDB and MongoDB. Data in the databases stays.</p>
<form method="post" action="/accounts/${a.name}/delete" data-confirm="Delete account ${a.name} from both databases?">${csrf(me)}<button class="danger">Delete ${a.name}</button></form></div>` : ''}
</div>` : ''}`, flash);
}

function message(me, title, msg) {
  return layout(me, title, html`<div class="card"><h1>${title}</h1><p>${msg}</p><p><a href="/">Back</a></p></div>`);
}

module.exports = { layout, login, home, account, message, esc };
