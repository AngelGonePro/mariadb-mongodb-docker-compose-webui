'use strict';
// Everything that touches MariaDB and MongoDB.
//
// One panel account = one MariaDB user ('name'@'%') + MongoDB users with the
// same name and password:
//   * one in the "admin" database holding the roles for every granted
//     database (for plugins that use a connection URI with authSource=admin)
//   * one inside each granted database holding only that database's role
//     (for plugins that log in against their own database - most of them).
// The panel's own records live in MariaDB, in the PANEL_SCHEMA database.

const mysql = require('mysql2/promise');
const { MongoClient } = require('mongodb');
const cfg = require('./config');
const sec = require('./security');

const LEVELS = ['read', 'readwrite', 'admin'];
const LEVEL_LABEL = { read: 'Read only', readwrite: 'Read & write', admin: 'Full' };
const levelRank = (l) => LEVELS.indexOf(l);

const NAME_RE = /^[A-Za-z][A-Za-z0-9_]{1,31}$/;
const DB_RE = /^[A-Za-z0-9_]{1,63}$/;

const MARIA_SYSTEM = new Set(['information_schema', 'mysql', 'performance_schema', 'sys']);
const MONGO_SYSTEM = new Set(['admin', 'local', 'config']);

// mysql.db columns each level should end up with. "admin" = every database
// privilege the server has except GRANT OPTION.
const RW_COLS = ['Select_priv', 'Insert_priv', 'Update_priv', 'Delete_priv', 'Create_priv', 'Drop_priv',
  'Alter_priv', 'Index_priv', 'References_priv', 'Create_tmp_table_priv', 'Lock_tables_priv',
  'Create_view_priv', 'Show_view_priv', 'Trigger_priv', 'Execute_priv'];
const LEVEL_PRIVS = {
  read: 'SELECT, SHOW VIEW',
  readwrite: 'SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, ALTER, INDEX, REFERENCES, ' +
    'CREATE TEMPORARY TABLES, LOCK TABLES, CREATE VIEW, SHOW VIEW, TRIGGER, EXECUTE',
  admin: 'ALL PRIVILEGES',
};
const MONGO_ROLES = { read: ['read'], readwrite: ['readWrite'], admin: ['readWrite', 'dbAdmin'] };

let pool;
let mongo;
let privCols = []; // the *_priv columns this MariaDB version has in mysql.db

const S = () => '`' + cfg.panelSchema + '`';
const qi = (name) => '`' + String(name).replace(/`/g, '``') + '`';
// In GRANT/REVOKE, _ and % in a database name are wildcards: escape them so
// `my_db` never also matches `myXdb`.
const grantDb = (db) => '`' + String(db).replace(/([\\_%])/g, '\\$1').replace(/`/g, '``') + '`';
const unescapeDb = (s) => s.replace(/\\([\\_%])/g, '$1');

class PanelError extends Error {}

// ---------------------------------------------------------------- connect ---
async function connect() {
  const deadline = Date.now() + 180000;
  for (;;) {
    try {
      pool = mysql.createPool({
        ...(cfg.mariadb.socket ? { socketPath: cfg.mariadb.socket } : { host: cfg.mariadb.host, port: cfg.mariadb.port }),
        user: 'root',
        password: cfg.mariadb.rootPassword, connectionLimit: 4, charset: 'utf8mb4',
      });
      await pool.query('SELECT 1');
      mongo = new MongoClient(
        `mongodb://${encodeURIComponent(cfg.mongo.rootUser)}:${encodeURIComponent(cfg.mongo.rootPassword)}` +
        `@${cfg.mongo.host}:${cfg.mongo.port}/?authSource=admin`,
        { serverSelectionTimeoutMS: 5000, appName: 'mc-databases-panel' });
      await mongo.connect();
      await mongo.db('admin').command({ ping: 1 });
      break;
    } catch (e) {
      await pool?.end().catch(() => {});
      await mongo?.close().catch(() => {});
      if (Date.now() > deadline) throw e;
      console.log('waiting for databases: ' + e.message);
      await new Promise((r) => setTimeout(r, 3000));
    }
  }
  await pool.query(`CREATE DATABASE IF NOT EXISTS ${S()} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ${S()}.accounts (
      name VARCHAR(32) NOT NULL PRIMARY KEY,
      secret TEXT NOT NULL,
      pw_version INT NOT NULL DEFAULT 1,
      note VARCHAR(200) NOT NULL DEFAULT '',
      created_by VARCHAR(64) NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ${S()}.grants (
      account VARCHAR(32) NOT NULL,
      db VARCHAR(64) NOT NULL,
      level ENUM('read','readwrite','admin') NOT NULL,
      manage TINYINT(1) NOT NULL DEFAULT 0,
      PRIMARY KEY (account, db),
      FOREIGN KEY (account) REFERENCES ${S()}.accounts(name) ON DELETE CASCADE
    ) ENGINE=InnoDB`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ${S()}.dbs (
      name VARCHAR(64) NOT NULL PRIMARY KEY,
      created_by VARCHAR(64) NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB`);
  await pool.query(`CREATE TABLE IF NOT EXISTS ${S()}.settings (
      k VARCHAR(64) NOT NULL PRIMARY KEY, v TEXT NOT NULL) ENGINE=InnoDB`);
  const [cols] = await pool.query("SHOW COLUMNS FROM mysql.db LIKE '%\\_priv'");
  privCols = cols.map((c) => c.Field);
}

async function ping() {
  await pool.query('SELECT 1');
  await mongo.db('admin').command({ ping: 1 });
}

// ------------------------------------------------------------ the .env admin ---
// The admin from .env is a superuser in both databases (so it also logs in to
// phpMyAdmin), with its password kept in step with .env on every start.
async function ensureAdmin() {
  const name = cfg.adminUser;
  const pw = cfg.adminPassword;
  const [[clash]] = await pool.query(`SELECT name FROM ${S()}.accounts WHERE name = ?`, [name]);
  if (clash) throw new Error(`ADMIN_USERNAME "${name}" is also a panel account - pick another admin name`);

  const u = pool.escape(name) + "@'%'";
  await pool.query(`CREATE USER IF NOT EXISTS ${u} IDENTIFIED BY ?`, [pw]);
  await pool.query(`ALTER USER ${u} IDENTIFIED BY ?`, [pw]);
  await pool.query(`GRANT ALL PRIVILEGES ON *.* TO ${u} WITH GRANT OPTION`);
  await mongoEnsureUser('admin', name, pw, [{ role: 'root', db: 'admin' }]);

  // ADMIN_USERNAME changed: remove the previous admin from both databases.
  const [[prev]] = await pool.query(`SELECT v FROM ${S()}.settings WHERE k = 'admin_user'`);
  if (prev && prev.v !== name && !(await accountRow(prev.v))) {
    if (prev.v.toLowerCase() !== 'root' && prev.v !== cfg.mongo.rootUser) {
      await pool.query(`DROP USER IF EXISTS ${pool.escape(prev.v)}@'%'`);
      await mongoDropUser('admin', prev.v);
      console.log(`removed previous admin "${prev.v}" from both databases`);
    }
  }
  await pool.query(`REPLACE INTO ${S()}.settings (k, v) VALUES ('admin_user', ?)`, [name]);
}

// ------------------------------------------------------------------ mongo ---
async function mongoUserExists(db, name) {
  const r = await mongo.db(db).command({ usersInfo: name });
  return r.users.length > 0;
}
async function mongoEnsureUser(db, name, pwd, roles) {
  if (await mongoUserExists(db, name)) await mongo.db(db).command({ updateUser: name, pwd, roles });
  else await mongo.db(db).command({ createUser: name, pwd, roles });
}
async function mongoDropUser(db, name) {
  try {
    await mongo.db(db).command({ dropUser: name });
  } catch (e) {
    if (e.code !== 11) throw e; // 11 = UserNotFound
  }
}
async function mongoDbsWithUser(name) {
  const r = await mongo.db('admin').command({ usersInfo: { forAllDBs: true } });
  return r.users.filter((u) => u.user === name).map((u) => u.db);
}

// ---------------------------------------------------------------- mariadb ---
async function mariaUserExists(name) {
  const [r] = await pool.query("SELECT 1 FROM mysql.user WHERE User = ? AND Host = '%'", [name]);
  return r.length > 0;
}

function wantedCols(level) {
  if (level === 'admin') return privCols.filter((c) => c !== 'Grant_priv');
  if (level === 'read') return ['Select_priv', 'Show_view_priv'];
  return RW_COLS.filter((c) => privCols.includes(c));
}

async function mariaApplyGrants(name, grants) {
  const u = pool.escape(name) + "@'%'";
  const [rows] = await pool.query("SELECT * FROM mysql.db WHERE User = ? AND Host = '%'", [name]);
  const current = new Map(rows.map((r) => [unescapeDb(r.Db), r]));
  const dbs = new Set([...current.keys(), ...grants.keys()]);
  for (const db of dbs) {
    const level = grants.get(db);
    const row = current.get(db);
    if (level && row) {
      const have = privCols.filter((c) => row[c] === 'Y').sort().join(',');
      if (have === wantedCols(level).sort().join(',')) continue; // already right
    }
    if (row) {
      await pool.query(`REVOKE ALL PRIVILEGES ON ${grantDb(db)}.* FROM ${u}`);
      if (row.Grant_priv === 'Y') await pool.query(`REVOKE GRANT OPTION ON ${grantDb(db)}.* FROM ${u}`);
    }
    if (level) await pool.query(`GRANT ${LEVEL_PRIVS[level]} ON ${grantDb(db)}.* TO ${u}`);
  }
}

// ---------------------------------------------------- convergence (both) ---
// Makes both databases match what the panel has for this account. Safe to
// repeat: creates missing users, fixes passwords, adds/removes access.
async function applyAccount(name, password, grants /* Map db -> level */) {
  // MariaDB
  const u = pool.escape(name) + "@'%'";
  if (await mariaUserExists(name)) await pool.query(`ALTER USER ${u} IDENTIFIED BY ?`, [password]);
  else await pool.query(`CREATE USER ${u} IDENTIFIED BY ?`, [password]);
  await mariaApplyGrants(name, grants);

  // MongoDB: the admin-database user with every role...
  const all = [];
  for (const [db, level] of grants) for (const role of MONGO_ROLES[level]) all.push({ role, db });
  await mongoEnsureUser('admin', name, password, all);
  // ...and one user per granted database.
  for (const [db, level] of grants)
    await mongoEnsureUser(db, name, password, MONGO_ROLES[level].map((role) => ({ role, db })));
  for (const db of await mongoDbsWithUser(name))
    if (db !== 'admin' && !grants.has(db)) await mongoDropUser(db, name);
}

async function removeFromServers(name) {
  await pool.query(`DROP USER IF EXISTS ${pool.escape(name)}@'%'`);
  for (const db of await mongoDbsWithUser(name)) await mongoDropUser(db, name);
}

// ------------------------------------------------------------ panel data ---
async function accountRow(name) {
  const [[r]] = await pool.query(`SELECT * FROM ${S()}.accounts WHERE name = ?`, [name]);
  return r || null;
}

async function grantsOf(name) {
  const [rows] = await pool.query(`SELECT db, level, manage FROM ${S()}.grants WHERE account = ? ORDER BY db`, [name]);
  return new Map(rows.map((r) => [r.db, { level: r.level, manage: !!r.manage }]));
}

const levelsOnly = (g) => new Map([...g].map(([db, v]) => [db, v.level]));

async function listAccounts() {
  const [accts] = await pool.query(`SELECT name, note, created_by, created_at FROM ${S()}.accounts ORDER BY name`);
  const [grants] = await pool.query(`SELECT account, db, level, manage FROM ${S()}.grants ORDER BY db`);
  const by = new Map(accts.map((a) => [a.name, { ...a, grants: new Map() }]));
  for (const g of grants) by.get(g.account)?.grants.set(g.db, { level: g.level, manage: !!g.manage });
  return [...by.values()];
}

function reservedName(name) {
  const l = name.toLowerCase();
  return l === 'root' || l === 'healthcheck' || l === 'public' || l === 'mariadb' ||
    name === cfg.mongo.rootUser || name === cfg.adminUser;
}

async function createAccount({ name, password, note, grants, createdBy }) {
  if (!NAME_RE.test(name)) throw new PanelError('Account names are 2-32 characters: a letter, then letters, digits or _.');
  if (reservedName(name)) throw new PanelError(`"${name}" is reserved.`);
  if (password.length < cfg.minPasswordLength) throw new PanelError(`Passwords need at least ${cfg.minPasswordLength} characters.`);
  if (await accountRow(name)) throw new PanelError(`An account named "${name}" already exists.`);
  if (await mariaUserExists(name)) throw new PanelError(`MariaDB already has a user "${name}" that this panel did not create.`);
  const strays = await mongoDbsWithUser(name);
  if (strays.length) throw new PanelError(`MongoDB already has a user "${name}" (in ${strays.join(', ')}) that this panel did not create.`);

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    await conn.query(`INSERT INTO ${S()}.accounts (name, secret, note, created_by) VALUES (?, ?, ?, ?)`,
      [name, sec.encrypt(password), note.slice(0, 200), createdBy]);
    for (const [db, g] of grants)
      await conn.query(`INSERT INTO ${S()}.grants (account, db, level, manage) VALUES (?, ?, ?, ?)`, [name, db, g.level, g.manage ? 1 : 0]);
    await applyAccount(name, password, levelsOnly(grants));
    await conn.commit();
  } catch (e) {
    await conn.rollback().catch(() => {});
    await removeFromServers(name).catch(() => {});
    throw e;
  } finally {
    conn.release();
  }
}

async function passwordOf(name) {
  const a = await accountRow(name);
  if (!a) throw new PanelError('No such account.');
  return sec.decrypt(a.secret);
}

// changes: Map db -> {level, manage} | null (null = remove access)
async function updateGrants(name, changes) {
  const before = await grantsOf(name);
  const after = new Map(before);
  for (const [db, g] of changes) {
    if (g) after.set(db, g);
    else after.delete(db);
  }
  const password = await passwordOf(name);
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    for (const [db, g] of changes) {
      if (g) await conn.query(`REPLACE INTO ${S()}.grants (account, db, level, manage) VALUES (?, ?, ?, ?)`, [name, db, g.level, g.manage ? 1 : 0]);
      else await conn.query(`DELETE FROM ${S()}.grants WHERE account = ? AND db = ?`, [name, db]);
    }
    await applyAccount(name, password, levelsOnly(after));
    await conn.commit();
  } catch (e) {
    await conn.rollback().catch(() => {});
    await applyAccount(name, password, levelsOnly(before)).catch(() => {});
    throw e;
  } finally {
    conn.release();
  }
}

async function setPassword(name, password) {
  if (password.length < cfg.minPasswordLength) throw new PanelError(`Passwords need at least ${cfg.minPasswordLength} characters.`);
  const old = await passwordOf(name);
  const grants = levelsOnly(await grantsOf(name));
  try {
    await applyAccount(name, password, grants);
  } catch (e) {
    await applyAccount(name, old, grants).catch(() => {});
    throw e;
  }
  await pool.query(`UPDATE ${S()}.accounts SET secret = ?, pw_version = pw_version + 1 WHERE name = ?`, [sec.encrypt(password), name]);
}

async function deleteAccount(name) {
  await removeFromServers(name);
  await pool.query(`DELETE FROM ${S()}.accounts WHERE name = ?`, [name]);
}

// Re-applies every account to both servers. Returns a list of problems.
async function syncAll() {
  const out = [];
  for (const a of await listAccounts()) {
    try {
      await applyAccount(a.name, await passwordOf(a.name), levelsOnly(a.grants));
    } catch (e) {
      out.push(`${a.name}: ${e.message}`);
    }
  }
  return out;
}

// --------------------------------------------------------------- databases ---
async function listDatabases() {
  const [m] = await pool.query('SHOW DATABASES');
  const maria = m.map((r) => r.Database).filter((d) => !MARIA_SYSTEM.has(d) && d !== cfg.panelSchema);
  const mg = (await mongo.db('admin').admin().listDatabases({ nameOnly: true })).databases
    .map((d) => d.name).filter((d) => !MONGO_SYSTEM.has(d));
  const [reg] = await pool.query(`SELECT name FROM ${S()}.dbs`);
  const names = new Set([...maria, ...mg, ...reg.map((r) => r.name)]);
  return [...names].filter((d) => DB_RE.test(d)).sort((a, b) => a.localeCompare(b)).map((name) => ({
    name, inMaria: maria.includes(name), inMongo: mg.includes(name),
  }));
}

async function createDatabase(name, createdBy) {
  if (!DB_RE.test(name)) throw new PanelError('Database names are 1-63 characters: letters, digits or _.');
  if (MARIA_SYSTEM.has(name.toLowerCase()) || MONGO_SYSTEM.has(name.toLowerCase()) || name === cfg.panelSchema)
    throw new PanelError(`"${name}" is a system database name.`);
  await pool.query(`CREATE DATABASE IF NOT EXISTS ${qi(name)} CHARACTER SET ${cfg.mariadb.charset} COLLATE ${cfg.mariadb.collation}`);
  // MongoDB has no empty databases: this one appears once a plugin writes to
  // it. Users and roles for it work before that.
  await pool.query(`INSERT IGNORE INTO ${S()}.dbs (name, created_by) VALUES (?, ?)`, [name, createdBy]);
}

async function dropDatabase(name) {
  if (!DB_RE.test(name) || name === cfg.panelSchema) throw new PanelError('Not a database this panel manages.');
  const [users] = await pool.query(`SELECT account FROM ${S()}.grants WHERE db = ?`, [name]);
  for (const { account } of users) await updateGrants(account, new Map([[name, null]]));
  await pool.query(`DROP DATABASE IF EXISTS ${qi(name)}`);
  await mongo.db(name).dropDatabase();
  await pool.query(`DELETE FROM ${S()}.dbs WHERE name = ?`, [name]);
}

module.exports = {
  LEVELS, LEVEL_LABEL, levelRank, NAME_RE, DB_RE, PanelError,
  connect, ping, ensureAdmin,
  accountRow, grantsOf, listAccounts, createAccount, updateGrants, setPassword, deleteAccount,
  passwordOf, syncAll, listDatabases, createDatabase, dropDatabase,
};
