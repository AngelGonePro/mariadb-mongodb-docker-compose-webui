'use strict';
// Every value comes from the environment (docker-compose.yml passes it from .env).

function str(k, d = '') {
  const v = process.env[k];
  return v === undefined || v === '' ? d : v;
}
function int(k, d) {
  const v = parseInt(str(k, ''), 10);
  return Number.isFinite(v) ? v : d;
}

const cfg = {
  listenPort: int('PANEL_LISTEN_PORT', 8080),
  title: str('PANEL_TITLE', 'Minecraft Databases'),

  adminUser: str('ADMIN_USERNAME', 'admin'),
  adminPassword: str('ADMIN_PASSWORD'),

  sessionSecret: str('SESSION_SECRET'),
  credentialKey: str('CREDENTIAL_KEY'),
  sessionHours: int('SESSION_HOURS', 12),
  cookieSecure: str('COOKIE_SECURE', 'auto'), // auto | true | false
  trustedProxies: str('TRUSTED_PROXIES'),
  loginMaxFailures: int('LOGIN_MAX_FAILURES', 8),
  loginBlockMinutes: int('LOGIN_BLOCK_MINUTES', 15),
  minPasswordLength: int('MIN_PASSWORD_LENGTH', 12),
  generatedPasswordLength: int('GENERATED_PASSWORD_LENGTH', 24),

  panelSchema: str('PANEL_SCHEMA', 'dbpanel'),

  mariadb: {
    // The panel logs in as root over MariaDB's unix socket (root has no
    // network login at all); host/port are used only when the socket is unset.
    socket: str('MARIADB_SOCKET'),
    host: str('MARIADB_HOST', 'mariadb'),
    port: int('MARIADB_INTERNAL_PORT', 3306),
    rootPassword: str('MARIADB_ROOT_PASSWORD'),
    charset: str('MARIADB_DEFAULT_CHARSET', 'utf8mb4'),
    collation: str('MARIADB_DEFAULT_COLLATION', 'utf8mb4_unicode_ci'),
  },
  mongo: {
    host: str('MONGO_HOST', 'mongo'),
    port: int('MONGO_INTERNAL_PORT', 27017),
    rootUser: str('MONGO_ROOT_USERNAME', 'root'),
    rootPassword: str('MONGO_ROOT_PASSWORD'),
  },

  // What plugins use to reach the databases (shown in the panel only).
  publicMariaHost: str('PUBLIC_DB_HOST', 'YOUR-SERVER-IP'),
  publicMariaPort: int('MARIADB_PORT', 3306),
  publicMongoHost: str('PUBLIC_DB_HOST', 'YOUR-SERVER-IP'),
  publicMongoPort: int('MONGO_PORT', 27017),

  phpMyAdminUrl: str('PHPMYADMIN_URL'),
  mongoExpressUrl: str('MONGO_EXPRESS_URL'),
};

const problems = [];
if (!/^[A-Za-z][A-Za-z0-9_]{1,31}$/.test(cfg.adminUser))
  problems.push('ADMIN_USERNAME must be 2-32 characters: a letter, then letters, digits or _');
if (cfg.adminUser.toLowerCase() === 'root' || cfg.adminUser === cfg.mongo.rootUser)
  problems.push('ADMIN_USERNAME cannot be "root" or the same as MONGO_ROOT_USERNAME');
if (cfg.adminPassword.length < 8) problems.push('ADMIN_PASSWORD must be at least 8 characters');
if (cfg.sessionSecret.length < 32) problems.push('SESSION_SECRET must be at least 32 characters');
if (cfg.credentialKey.length < 32) problems.push('CREDENTIAL_KEY must be at least 32 characters');
if (!cfg.mariadb.rootPassword) problems.push('MARIADB_ROOT_PASSWORD is empty');
if (!cfg.mongo.rootPassword) problems.push('MONGO_ROOT_PASSWORD is empty');
if (!/^[A-Za-z0-9_]{1,64}$/.test(cfg.panelSchema)) problems.push('PANEL_SCHEMA must be letters, digits or _');
if (problems.length) {
  for (const p of problems) console.error('config error: ' + p);
  process.exit(1);
}

module.exports = cfg;
