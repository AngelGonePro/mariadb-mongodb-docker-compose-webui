#!/usr/bin/env bash
# ==============================================================================
# deploy-update.sh - install or update mc-databases from its release zip
# WITHOUT touching your real .env values or ./data.
#
#   From anywhere (what README.md's one-line command runs):
#     bash deploy-update.sh <zip file or URL> <install folder>
#   From an existing install folder:
#     ./deploy-update.sh            (downloads DEPLOY_ZIP_URL from .env)
#
# First run : puts the files in place, creates the admin password, database
#             root passwords and panel keys in .env, and stops so you can
#             check .env.
# Later runs: merges .env (your values kept, new settings appended, image pins
#             follow the release only if you left them at the old default),
#             pulls new images and builds the panel FIRST (nothing on disk
#             changes if that fails), dumps both databases to ./backups when
#             a database image changes, copies the new files, starts the stack
#             and waits until it answers.
#
# Never touched: .env values you set, ./data, ./backups.
# ==============================================================================
set -euo pipefail

say()  { printf '==> %s\n' "$*"; }
note() { printf '    %s\n' "$*"; }
die()  { printf 'ERROR: %s\n' "$*" >&2; exit 1; }

PROJECT_DIR_NAME=mc-databases
HEALTH_TIMEOUT=${HEALTH_TIMEOUT:-240}

for tool in python3 docker; do
  command -v "$tool" >/dev/null 2>&1 || die "'$tool' is required but not installed."
done
docker compose version >/dev/null 2>&1 || die "the Docker Compose plugin ('docker compose') is required."

# --- Where from, where to ------------------------------------------------------
SRC=${1:-}
DEST=${2:-}
if [ -z "$DEST" ]; then
  DEST="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  [ -f "$DEST/.env" ] || die "run this from your install folder, or pass: <zip file or URL> <install folder>"
fi
mkdir -p "$DEST"
DEST="$(cd "$DEST" && pwd)"
if [ -z "$SRC" ]; then
  SRC=$(sed -n 's/^DEPLOY_ZIP_URL=//p' "$DEST/.env" | tail -1)
  [ -n "$SRC" ] || die "no zip given and DEPLOY_ZIP_URL is empty in $DEST/.env"
fi

WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

# --- Get the zip ---------------------------------------------------------------
case "$SRC" in
  http://*|https://*|file://*)
    command -v curl >/dev/null 2>&1 || die "'curl' is required to download $SRC"
    say "Downloading $SRC"
    curl -fsSL -o "$WORK/release.zip" "$SRC" || die "download failed - install unchanged."
    ;;
  *)
    [ -f "$SRC" ] || die "$SRC does not exist - install unchanged."
    cp "$SRC" "$WORK/release.zip"
    ;;
esac

say "Extracting (stripping the top-level folder)"
python3 - "$WORK/release.zip" "$WORK/new" <<'PY' || die "that is not a valid release zip - install unchanged."
import os, sys, zipfile
src, out = sys.argv[1], sys.argv[2]
if not zipfile.is_zipfile(src):
    sys.exit("not a zip file (a 404 page instead of the release?)")
with zipfile.ZipFile(src) as z:
    names = [n for n in z.namelist() if not n.endswith("/")]
    tops = {n.split("/", 1)[0] for n in names}
    if len(tops) != 1 or not all("/" in n for n in names):
        sys.exit("expected everything inside one top-level folder")
    for n in names:
        rel = n.split("/", 1)[1]
        if rel.startswith("/") or ".." in rel.split("/"):
            sys.exit(f"unsafe path in zip: {n}")
        target = os.path.join(out, rel)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with open(target, "wb") as f:
            f.write(z.read(n))
        mode = (z.getinfo(n).external_attr >> 16) & 0o777
        if mode:
            os.chmod(target, mode)
for need in ("docker-compose.yml", ".env", "deploy-update.sh", "panel/Dockerfile", "panel/src/server.js"):
    if not os.path.isfile(os.path.join(out, need)):
        sys.exit(f"release is missing {need}")
PY

FIRST_RUN=0
[ -f "$DEST/.env" ] || FIRST_RUN=1

# --- Merge .env ----------------------------------------------------------------
say "Merging .env"
python3 - "$WORK/new/.env" "$DEST/.env" "$DEST/.release.env" "$WORK/env.merged" "$WORK/env.report" <<'PY'
import os, re, sys, secrets, string
tpl_path, cur_path, prev_path, out_path, report_path = sys.argv[1:]
KEY = re.compile(r'^([A-Za-z_][A-Za-z0-9_]*)=(.*)$')

def parse(path):
    vals = {}
    if os.path.isfile(path):
        for line in open(path, encoding="utf-8"):
            m = KEY.match(line.rstrip("\n"))
            if m:
                vals[m.group(1)] = m.group(2)
    return vals

tpl_lines = open(tpl_path, encoding="utf-8").read().splitlines()
tpl = parse(tpl_path)
cur_exists = os.path.isfile(cur_path)
cur = parse(cur_path)
prev = parse(prev_path)
report = []

if not cur_exists:
    out = list(tpl_lines)
    report.append("No existing .env - copied the template.")
else:
    out = open(cur_path, encoding="utf-8").read().splitlines()
    # Image pins: follow the release only if still at the previous release's value.
    for k, v in tpl.items():
        if k.endswith("_IMAGE") and k in cur and cur[k] != v:
            if prev.get(k) == cur[k]:
                out = [f"{k}={v}" if KEY.match(l) and KEY.match(l).group(1) == k else l for l in out]
                report.append(f"{k}: {cur[k]} -> {v} (release pin)")
            else:
                report.append(f"{k}: kept your {cur[k]} (release default is {v})")
    new = [k for k in tpl if k not in cur]
    if new:
        out.append("")
        out.append("# --- Added by deploy-update.sh from a newer release ---")
        for k in new:
            out.append(f"{k}={tpl[k]}")
            report.append(f"NEW setting {k}={tpl[k]} - review it")
    for k in cur:
        if k not in tpl:
            report.append(f"{k} is no longer used by this release (left in .env)")

def get(lines, k):
    for l in lines:
        m = KEY.match(l)
        if m and m.group(1) == k:
            return m.group(2)
    return None

def put(lines, k, v):
    for i, l in enumerate(lines):
        m = KEY.match(l)
        if m and m.group(1) == k:
            lines[i] = f"{k}={v}"
            return
    lines.append(f"{k}={v}")

# Letters and digits only: safe in URLs, YAML and shell.
alphabet = string.ascii_letters + string.digits
for k, n in (("ADMIN_PASSWORD", 20), ("MARIADB_ROOT_PASSWORD", 32), ("MONGO_ROOT_PASSWORD", 32),
             ("SESSION_SECRET", 48), ("CREDENTIAL_KEY", 48)):
    if not get(out, k):
        put(out, k, "".join(secrets.choice(alphabet) for _ in range(n)))
        report.append(f"Generated {k} (saved in .env).")

open(out_path, "w", encoding="utf-8").write("\n".join(out) + "\n")
open(report_path, "w", encoding="utf-8").write("\n".join(report) + ("\n" if report else ""))
PY

envget() { sed -n "s/^$1=//p" "$WORK/env.merged" | tail -1; }
show_report() { [ -s "$WORK/env.report" ] && sed 's/^/    /' "$WORK/env.report"; return 0; }

# --- Sanity checks on the merged values -----------------------------------------
NAME_RE='^[A-Za-z][A-Za-z0-9_]{1,31}$'
[[ $(envget ADMIN_USERNAME) =~ $NAME_RE ]] || die "ADMIN_USERNAME must be 2-32 letters, digits or _ (starting with a letter) - install unchanged."
[[ $(envget MONGO_ROOT_USERNAME) =~ $NAME_RE ]] || die "MONGO_ROOT_USERNAME must be 2-32 letters, digits or _ - install unchanged."
for k in MARIADB_ROOT_PASSWORD MONGO_ROOT_PASSWORD; do
  [[ $(envget "$k") =~ ^[A-Za-z0-9._~-]+$ ]] || die "$k may only use letters, digits and . _ ~ - (it goes into a connection URL) - install unchanged."
done
ADMIN_PW=$(envget ADMIN_PASSWORD)
[ "${#ADMIN_PW}" -ge 8 ] || die "ADMIN_PASSWORD must be at least 8 characters - install unchanged."
P=$(envget COMPOSE_PROJECT_NAME); P=${P:-mc-databases}

# Root passwords and the credential key only take effect when the data is
# first created. Refuse to start with values that no longer match it.
STAMP="$DEST/data/.applied-secrets"
fp() { printf '%s' "$1" | sha256sum | cut -c1-16; }
if [ -s "$STAMP" ]; then
  for k in MARIADB_ROOT_PASSWORD MONGO_ROOT_USERNAME MONGO_ROOT_PASSWORD CREDENTIAL_KEY; do
    want=$(sed -n "s/^$k=//p" "$STAMP")
    [ -z "$want" ] || [ "$want" = "$(fp "$(envget "$k")")" ] \
      || die "$k in .env differs from the one the databases were created with. Put the old value back (see .env.bak.*) - install unchanged."
  done
fi

# --- Validate the new compose file against the merged .env -----------------------
COMPOSE_NEW=(docker compose -p "$P" --project-directory "$WORK/new" -f "$WORK/new/docker-compose.yml" --env-file "$WORK/env.merged")
"${COMPOSE_NEW[@]}" config -q 2>"$WORK/config.err" \
  || { cat "$WORK/config.err" >&2; die "the release's docker-compose.yml does not work with your .env - install unchanged."; }

# --- Helpers ---------------------------------------------------------------------
copy_release() {
  ( cd "$WORK/new" && find . -type f ! -name .env -print0 ) | while IFS= read -r -d '' f; do
    f=${f#./}
    case "$f" in data/*|backups/*) continue ;; esac
    mkdir -p "$DEST/$(dirname "$f")"
    cp -p "$WORK/new/$f" "$DEST/$f"
  done
  chmod +x "$DEST/deploy-update.sh"
  cp "$WORK/new/.env" "$DEST/.release.env"
  ( cd "$WORK/new" && find . -type f ! -name .env | sed 's#^\./##' | sort ) > "$DEST/.release.files"
}
write_env() {
  if [ -f "$DEST/.env" ] && ! cmp -s "$DEST/.env" "$WORK/env.merged"; then
    cp -p "$DEST/.env" "$DEST/.env.bak.$(date +%Y%m%d-%H%M%S)"
  fi
  cp "$WORK/env.merged" "$DEST/.env"
  chmod 600 "$DEST/.env"
}

say "Applying files"
if [ "$FIRST_RUN" = 1 ]; then
  copy_release
  mkdir -p "$DEST/data/mariadb" "$DEST/data/mongo" "$DEST/data/mongo-config"
  write_env
  show_report
  echo
  say "Files are in place in $DEST, but nothing was started yet."
  note "Check these in $DEST/.env first:"
  for k in ADMIN_USERNAME PUBLIC_DB_HOST MARIADB_PORT MONGO_PORT DB_BIND PANEL_PORT PHPMYADMIN_PORT MONGO_EXPRESS_PORT WEB_BIND COMPOSE_PROFILES; do
    note "  $k=$(envget "$k")"
  done
  note "then run the same install/update command again to start it."
  exit 0
fi

# --- Later runs: get images and build the panel first, nothing changed yet -------
have_image() { docker image inspect "$1" >/dev/null 2>&1; }
profiles=",$(envget COMPOSE_PROFILES),"
images=("$(envget MARIADB_IMAGE)" "$(envget MONGO_IMAGE)" "$(envget PANEL_NODE_IMAGE)")
[[ $profiles == *,phpmyadmin,* ]] && images+=("$(envget PHPMYADMIN_IMAGE)")
[[ $profiles == *,mongo-express,* ]] && images+=("$(envget MONGO_EXPRESS_IMAGE)")
for img in "${images[@]}"; do
  if ! have_image "$img"; then
    say "Pulling $img"
    docker pull -q "$img" >/dev/null || die "could not pull $img - install unchanged."
  fi
done
say "Building the panel"
"${COMPOSE_NEW[@]}" build -q panel >"$WORK/build.log" 2>&1 \
  || { tail -20 "$WORK/build.log" >&2; die "the panel did not build - install unchanged."; }

# --- Database image changing: dump both first (upgrades are one-way) -------------
COMPOSE_CUR=(docker compose -p "$P" --project-directory "$DEST" -f "$DEST/docker-compose.yml" --env-file "$DEST/.env")
running() { [ -n "$("${COMPOSE_CUR[@]}" ps -q --status running "$1" 2>/dev/null)" ]; }
old_get() { sed -n "s/^$1=//p" "$DEST/.env" | tail -1; }
ts=$(date +%Y%m%d-%H%M%S)
if [ "$(old_get MARIADB_IMAGE)" != "$(envget MARIADB_IMAGE)" ] && running mariadb; then
  mkdir -p "$DEST/backups"
  say "MariaDB image changes ($(old_get MARIADB_IMAGE) -> $(envget MARIADB_IMAGE)): dumping all databases"
  "${COMPOSE_CUR[@]}" exec -T mariadb sh -c 'exec mariadb-dump -uroot -p"$MARIADB_ROOT_PASSWORD" --all-databases --single-transaction --routines --events' \
    | gzip > "$DEST/backups/mariadb-$ts.sql.gz" \
    || { rm -f "$DEST/backups/mariadb-$ts.sql.gz"; die "MariaDB dump failed - install unchanged."; }
  note "saved backups/mariadb-$ts.sql.gz"
fi
if [ "$(old_get MONGO_IMAGE)" != "$(envget MONGO_IMAGE)" ] && running mongo; then
  mkdir -p "$DEST/backups"
  say "MongoDB image changes ($(old_get MONGO_IMAGE) -> $(envget MONGO_IMAGE)): dumping all databases"
  "${COMPOSE_CUR[@]}" exec -T mongo sh -c 'exec mongodump --quiet --archive --gzip -u "$MONGO_INITDB_ROOT_USERNAME" -p "$MONGO_INITDB_ROOT_PASSWORD" --authenticationDatabase admin' \
    > "$DEST/backups/mongo-$ts.archive.gz" \
    || { rm -f "$DEST/backups/mongo-$ts.archive.gz"; die "MongoDB dump failed - install unchanged."; }
  note "saved backups/mongo-$ts.archive.gz (restore: mongorestore --archive --gzip)"
fi

# Report files the release no longer ships (they're left alone).
if [ -f "$DEST/.release.files" ]; then
  ( cd "$WORK/new" && find . -type f ! -name .env | sed 's#^\./##' | sort ) > "$WORK/files.new"
  comm -23 "$DEST/.release.files" "$WORK/files.new" | while read -r f; do
    [ -e "$DEST/$f" ] && note "$f is no longer part of the release (left in place)"
  done
fi

copy_release
mkdir -p "$DEST/data/mariadb" "$DEST/data/mongo" "$DEST/data/mongo-config"
write_env
show_report

say "Starting"
cd "$DEST"
docker compose build -q panel >/dev/null
docker compose up -d --no-build --remove-orphans >"$WORK/up.log" 2>&1 \
  || { tail -20 "$WORK/up.log" >&2; docker compose ps; die "the stack did not start. See: docker compose logs"; }

# --- Wait until it answers --------------------------------------------------------
deadline=$(( $(date +%s) + HEALTH_TIMEOUT ))
while :; do
  ok=1; states=""
  for id in $(docker compose ps -aq); do
    read -r svc run health < <(docker inspect -f '{{index .Config.Labels "com.docker.compose.service"}} {{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{end}}' "$id" 2>/dev/null || echo "? missing")
    [ "$run" = running ] || ok=0
    [ -z "${health:-}" ] || [ "$health" = healthy ] || ok=0
    states+="$svc=${health:-$run} "
  done
  [ "$ok" = 1 ] && [ -n "$states" ] && break
  if [ "$(date +%s)" -ge "$deadline" ]; then
    docker compose ps
    die "stack never became ready within ${HEALTH_TIMEOUT}s ($states). See: docker compose logs"
  fi
  sleep 3
done

# Record which root passwords / key the data now uses.
{
  for k in MARIADB_ROOT_PASSWORD MONGO_ROOT_USERNAME MONGO_ROOT_PASSWORD CREDENTIAL_KEY; do
    printf '%s=%s\n' "$k" "$(fp "$(envget "$k")")"
  done
} > "$STAMP"
chmod 600 "$STAMP"

host=$(envget PUBLIC_DB_HOST); host=${host:-<this host>}
echo
say "ok - $states"
note "Panel      : http://<this host>:$(envget PANEL_PORT)  ($(envget PANEL_URL) behind your proxy)"
note "Admin login: $(envget ADMIN_USERNAME) / ADMIN_PASSWORD in .env  (also phpMyAdmin and Mongo Express)"
note "Plugins    : MariaDB $host:$(envget MARIADB_PORT)   MongoDB $host:$(envget MONGO_PORT)"
